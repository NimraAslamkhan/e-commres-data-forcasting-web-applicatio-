import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta
import io
from data_processor import DataProcessor
from forecasting import SalesForecaster
from visualization import Visualizer

# Set page configuration
st.set_page_config(
    page_title="E-Commerce Analytics Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'data_loaded' not in st.session_state:
    st.session_state.data_loaded = False
if 'processed_data' not in st.session_state:
    st.session_state.processed_data = None
if 'raw_data' not in st.session_state:
    st.session_state.raw_data = None

def main():
    # Custom CSS for better styling
    st.markdown("""
    <style>
    .main-header {
        color: #1f77b4;
        text-align: center;
        padding: 1rem 0;
        background: linear-gradient(90deg, #f8fafc 0%, #e6f3ff 50%, #f8fafc 100%);
        border-radius: 10px;
        margin-bottom: 2rem;
    }
    .metric-container {
        background: linear-gradient(135deg, #ffffff 0%, #e6f3ff 100%);
        padding: 1rem;
        border-radius: 10px;
        border: 1px solid #bfdbfe;
        text-align: center;
    }
    .tab-container {
        background: #f8fafc;
        border-radius: 10px;
        padding: 1rem;
    }
    .stButton > button {
        background: linear-gradient(90deg, #3b82f6 0%, #1d4ed8 100%);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.5rem 1rem;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    .stButton > button:hover {
        background: linear-gradient(90deg, #2563eb 0%, #1e40af 100%);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(59, 130, 246, 0.4);
    }
    .sidebar .stRadio > div {
        background: #f1f5f9;
        border-radius: 8px;
        padding: 0.5rem;
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.markdown('<div class="main-header"><h1>📊 E-Commerce Analytics & Forecasting Dashboard</h1><p>Upload your sales data to get comprehensive business insights and forecasting</p></div>', unsafe_allow_html=True)
    
    # Sidebar for data upload
    with st.sidebar:
        st.header("📁 Data Upload")
        
        # Option to use sample data or upload file
        data_option = st.radio("Choose data source:", ["Use Sample Data", "Upload File"])
        
        if data_option == "Use Sample Data":
            if st.button("Generate Sample Data", type="primary"):
                # Generate sample e-commerce data
                np.random.seed(42)
                
                products = ['Wireless Headphones', 'Smartphone Case', 'Bluetooth Speaker', 'Laptop Stand', 
                           'USB Cable', 'Wireless Mouse', 'Keyboard', 'Monitor', 'Tablet', 'Smart Watch']
                categories = ['Electronics', 'Accessories', 'Audio', 'Computer Hardware', 'Wearables']
                
                dates = pd.date_range(start='2023-01-01', end='2024-01-31', freq='D')
                
                sample_data = []
                for _ in range(500):  # Generate 500 sample records
                    sample_data.append({
                        'date': np.random.choice(dates),
                        'product_name': np.random.choice(products),
                        'category': np.random.choice(categories),
                        'quantity': np.random.randint(1, 10),
                        'selling_price': np.round(np.random.uniform(10, 200), 2),
                        'cost_price': None  # Will be calculated with 30% margin
                    })
                
                df = pd.DataFrame(sample_data)
                # Add cost price with some variation around 70% of selling price
                df['cost_price'] = df['selling_price'] * np.random.uniform(0.6, 0.8, len(df))
                df['cost_price'] = df['cost_price'].round(2)
                
                st.session_state.raw_data = df
                
                # Process the data
                processor = DataProcessor()
                processed_df = processor.process_data(df)
                st.session_state.processed_data = processed_df
                st.session_state.data_loaded = True
                
                st.success(f"✅ Sample data generated! {len(df)} records created")
                
                # Display data info
                st.subheader("📋 Data Overview")
                st.write(f"**Rows:** {len(df)}")
                st.write(f"**Columns:** {len(df.columns)}")
                st.write(f"**Date Range:** {processed_df['date'].min().strftime('%Y-%m-%d')} to {processed_df['date'].max().strftime('%Y-%m-%d')}")
                
        else:
            uploaded_file = st.file_uploader(
                "Upload Sales Data",
                type=['csv', 'xlsx', 'xls'],
                help="Upload CSV or Excel file with sales data"
            )
        
            if uploaded_file is not None:
                try:
                    # Read the uploaded file
                    if uploaded_file.name.endswith('.csv'):
                        df = pd.read_csv(uploaded_file)
                    else:
                        df = pd.read_excel(uploaded_file)
                    
                    st.session_state.raw_data = df
                    
                    # Process the data
                    processor = DataProcessor()
                    processed_df = processor.process_data(df)
                    st.session_state.processed_data = processed_df
                    st.session_state.data_loaded = True
                    
                    st.success(f"✅ Data loaded successfully! {len(df)} records processed")
                    
                    # Display data info
                    st.subheader("📋 Data Overview")
                    st.write(f"**Rows:** {len(df)}")
                    st.write(f"**Columns:** {len(df.columns)}")
                    st.write(f"**Date Range:** {processed_df['date'].min().strftime('%Y-%m-%d')} to {processed_df['date'].max().strftime('%Y-%m-%d')}")
                    
                except Exception as e:
                    st.error(f"❌ Error loading data: {str(e)}")
                    st.info("💡 You can try using the sample data option above to test the dashboard features")
                    st.session_state.data_loaded = False
    
    # Main content area
    if st.session_state.data_loaded and st.session_state.processed_data is not None:
        df = st.session_state.processed_data
        visualizer = Visualizer()
        
        # Create tabs for different analyses
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📈 Sales Overview", 
            "🏆 Product Analysis", 
            "💰 Profit Analysis", 
            "🔮 Sales Forecasting", 
            "📊 Reports"
        ])
        
        with tab1:
            st.header("📈 Sales Overview")
            
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                total_sales = df['total_sales'].sum()
                st.markdown(f'<div class="metric-container"><h3 style="color: #1f77b4; margin: 0;">Total Sales</h3><h2 style="color: #059669; margin: 0;">${total_sales:,.2f}</h2></div>', unsafe_allow_html=True)
            
            with col2:
                total_profit = df['profit'].sum()
                st.markdown(f'<div class="metric-container"><h3 style="color: #1f77b4; margin: 0;">Total Profit</h3><h2 style="color: #059669; margin: 0;">${total_profit:,.2f}</h2></div>', unsafe_allow_html=True)
            
            with col3:
                avg_order_value = df['total_sales'].mean()
                st.markdown(f'<div class="metric-container"><h3 style="color: #1f77b4; margin: 0;">Avg Order Value</h3><h2 style="color: #059669; margin: 0;">${avg_order_value:.2f}</h2></div>', unsafe_allow_html=True)
            
            with col4:
                profit_margin = (total_profit / total_sales * 100) if total_sales > 0 else 0
                st.markdown(f'<div class="metric-container"><h3 style="color: #1f77b4; margin: 0;">Profit Margin</h3><h2 style="color: #059669; margin: 0;">{profit_margin:.1f}%</h2></div>', unsafe_allow_html=True)
            
            # Time period selector
            time_period = st.selectbox("Select Time Period", ["Daily", "Weekly", "Monthly"])
            
            # Sales trends
            sales_trend_fig = visualizer.create_sales_trend(df, time_period.lower())
            st.plotly_chart(sales_trend_fig, use_container_width=True)
            
            # Sales by category (if category column exists)
            if 'category' in df.columns:
                category_fig = visualizer.create_category_analysis(df)
                st.plotly_chart(category_fig, use_container_width=True)
        
        with tab2:
            st.header("🏆 Product Analysis")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Top Selling Products")
                top_products = df.groupby('product_name').agg({
                    'quantity': 'sum',
                    'total_sales': 'sum',
                    'profit': 'sum'
                }).sort_values('total_sales', ascending=False).head(10)
                
                top_products_fig = visualizer.create_top_products_chart(top_products, "total_sales")
                st.plotly_chart(top_products_fig, use_container_width=True)
                
                st.dataframe(top_products.round(2), use_container_width=True)
            
            with col2:
                st.subheader("Worst Performing Products")
                worst_products = df.groupby('product_name').agg({
                    'quantity': 'sum',
                    'total_sales': 'sum',
                    'profit': 'sum'
                }).sort_values('total_sales', ascending=True).head(10)
                
                worst_products_fig = visualizer.create_top_products_chart(worst_products, "total_sales", ascending=True)
                st.plotly_chart(worst_products_fig, use_container_width=True)
                
                st.dataframe(worst_products.round(2), use_container_width=True)
        
        with tab3:
            st.header("💰 Profit Analysis")
            
            # Profit metrics
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Most Profitable Products")
                profitable_products = df.groupby('product_name').agg({
                    'profit': 'sum',
                    'total_sales': 'sum',
                    'quantity': 'sum'
                }).sort_values('profit', ascending=False).head(10)
                
                profitable_products['profit_margin'] = (profitable_products['profit'] / profitable_products['total_sales'] * 100).round(2)
                
                profit_fig = visualizer.create_profit_analysis(profitable_products)
                st.plotly_chart(profit_fig, use_container_width=True)
                
                st.dataframe(profitable_products, use_container_width=True)
            
            with col2:
                st.subheader("Low Profit Products (Consider Discontinuing)")
                low_profit = df.groupby('product_name').agg({
                    'profit': 'sum',
                    'total_sales': 'sum',
                    'quantity': 'sum'
                }).sort_values('profit', ascending=True).head(10)
                
                low_profit['profit_margin'] = (low_profit['profit'] / low_profit['total_sales'] * 100).round(2)
                
                low_profit_fig = visualizer.create_profit_analysis(low_profit, is_low_profit=True)
                st.plotly_chart(low_profit_fig, use_container_width=True)
                
                st.dataframe(low_profit, use_container_width=True)
        
        with tab4:
            st.header("🔮 Sales Forecasting")
            
            try:
                forecaster = SalesForecaster()
                
                # Forecast parameters
                col1, col2 = st.columns(2)
                with col1:
                    forecast_days = st.slider("Forecast Days", 7, 365, 30)
                with col2:
                    forecast_level = st.selectbox("Forecast Level", ["Total Sales", "By Product"])
                
                if st.button("Generate Forecast", type="primary"):
                    with st.spinner("Generating forecast..."):
                        if forecast_level == "Total Sales":
                            forecast_fig, forecast_data = forecaster.forecast_total_sales(df, forecast_days)
                            st.plotly_chart(forecast_fig, use_container_width=True)
                            
                            # Display forecast summary
                            st.subheader("📊 Forecast Summary")
                            col1, col2, col3 = st.columns(3)
                            
                            with col1:
                                next_week_forecast = forecast_data.head(7)['yhat'].sum()
                                st.metric("Next 7 Days", f"${next_week_forecast:,.2f}")
                            
                            with col2:
                                next_month_forecast = forecast_data.head(30)['yhat'].sum()
                                st.metric("Next 30 Days", f"${next_month_forecast:,.2f}")
                            
                            with col3:
                                total_forecast = forecast_data['yhat'].sum()
                                st.metric(f"Next {forecast_days} Days", f"${total_forecast:,.2f}")
                            
                            # Download forecast data
                            csv = forecast_data.to_csv(index=False)
                            st.download_button(
                                label="📥 Download Forecast Data",
                                data=csv,
                                file_name=f"sales_forecast_{datetime.now().strftime('%Y%m%d')}.csv",
                                mime="text/csv"
                            )
                        
                        else:  # By Product
                            st.info("Select a product to forecast")
                            product_list = df['product_name'].unique()
                            selected_product = st.selectbox("Select Product", product_list)
                            
                            if selected_product:
                                product_forecast_fig, product_forecast_data = forecaster.forecast_product_sales(
                                    df, selected_product, forecast_days
                                )
                                st.plotly_chart(product_forecast_fig, use_container_width=True)
                                
                                # Product forecast summary
                                next_month_product = product_forecast_data.head(30)['yhat'].sum()
                                st.metric(f"Next 30 Days - {selected_product}", f"${next_month_product:,.2f}")
            
            except Exception as e:
                st.error(f"❌ Error generating forecast: {str(e)}")
                st.info("💡 Ensure your data has at least 30 days of historical data for accurate forecasting")
        
        with tab5:
            st.header("📊 Reports & Export")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("📈 Business Summary Report")
                
                # Generate summary stats
                summary_stats = {
                    "Total Sales": f"${df['total_sales'].sum():,.2f}",
                    "Total Profit": f"${df['profit'].sum():,.2f}",
                    "Average Order Value": f"${df['total_sales'].mean():.2f}",
                    "Total Orders": len(df),
                    "Unique Products": df['product_name'].nunique(),
                    "Date Range": f"{df['date'].min().strftime('%Y-%m-%d')} to {df['date'].max().strftime('%Y-%m-%d')}"
                }
                
                for key, value in summary_stats.items():
                    st.write(f"**{key}:** {value}")
                
                # Top 5 products by sales
                st.subheader("🏆 Top 5 Products by Sales")
                top_5 = df.groupby('product_name')['total_sales'].sum().sort_values(ascending=False).head(5)
                for i, (product, sales) in enumerate(top_5.items(), 1):
                    st.write(f"{i}. {product}: ${sales:,.2f}")
            
            with col2:
                st.subheader("💾 Export Options")
                
                # Export processed data
                processed_csv = df.to_csv(index=False)
                st.download_button(
                    label="📥 Download Processed Data (CSV)",
                    data=processed_csv,
                    file_name=f"processed_sales_data_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
                
                # Export summary report
                summary_df = pd.DataFrame(list(summary_stats.items()), columns=['Metric', 'Value'])
                summary_csv = summary_df.to_csv(index=False)
                st.download_button(
                    label="📥 Download Summary Report (CSV)",
                    data=summary_csv,
                    file_name=f"business_summary_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
                
                # Export top products
                top_products_data = df.groupby('product_name').agg({
                    'quantity': 'sum',
                    'total_sales': 'sum',
                    'profit': 'sum'
                }).sort_values('total_sales', ascending=False)
                
                top_products_csv = top_products_data.to_csv()
                st.download_button(
                    label="📥 Download Product Analysis (CSV)",
                    data=top_products_csv,
                    file_name=f"product_analysis_{datetime.now().strftime('%Y%m%d')}.csv",
                    mime="text/csv"
                )
    
    else:
        # Welcome screen
        st.markdown("""
        ## 👋 Welcome to E-Commerce Analytics Dashboard
        
        Get comprehensive insights from your sales data including:
        
        ### 📊 **Analytics Features**
        - **Sales Trends**: Daily, weekly, and monthly sales analysis
        - **Product Performance**: Top and worst-selling products
        - **Profit Analysis**: Profitability rankings and margin analysis
        - **Sales Forecasting**: Predict future sales using Prophet ML model
        - **Export Reports**: Download analysis results and forecasts
        
        ### 📁 **Supported Data Formats**
        - CSV files
        - Excel files (.xlsx, .xls)
        
        ### 📋 **Required Data Columns**
        Your data should include columns like:
        - Date (any common date format)
        - Product name/ID
        - Quantity sold
        - Selling price
        - Cost price (optional - for profit calculation)
        - Category (optional)
        
        ### 🚀 **Get Started**
        Upload your sales data using the sidebar to begin analysis!
        """)
        
        # Sample data format
        st.subheader("📝 Sample Data Format")
        sample_data = pd.DataFrame({
            'date': ['2024-01-01', '2024-01-02', '2024-01-03'],
            'product_name': ['Product A', 'Product B', 'Product A'],
            'quantity': [2, 1, 3],
            'selling_price': [29.99, 49.99, 29.99],
            'cost_price': [15.00, 25.00, 15.00],
            'category': ['Electronics', 'Clothing', 'Electronics']
        })
        st.dataframe(sample_data, use_container_width=True)

if __name__ == "__main__":
    main()
