import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import streamlit as st

try:
    from prophet import Prophet
    PROPHET_AVAILABLE = True
except ImportError:
    PROPHET_AVAILABLE = False

class SalesForecaster:
    def __init__(self):
        if not PROPHET_AVAILABLE:
            st.error("❌ Prophet library is not available. Forecasting features will be limited.")
    
    def forecast_total_sales(self, df, days=30):
        """
        Forecast total sales for the specified number of days
        """
        if not PROPHET_AVAILABLE:
            return self._simple_forecast(df, days)
        
        try:
            # Aggregate data by date
            daily_sales = df.groupby('date')['total_sales'].sum().reset_index()
            daily_sales.columns = ['ds', 'y']
            
            # Check if we have enough data
            if len(daily_sales) < 10:
                raise ValueError("Insufficient data for forecasting. Need at least 10 data points.")
            
            # Initialize and fit Prophet model
            model = Prophet(
                daily_seasonality=False,
                weekly_seasonality=True,
                yearly_seasonality=True if len(daily_sales) > 365 else False,
                interval_width=0.95
            )
            
            model.fit(daily_sales)
            
            # Create future dataframe
            future = model.make_future_dataframe(periods=days)
            forecast = model.predict(future)
            
            # Create visualization
            fig = self._create_forecast_plot(daily_sales, forecast, "Total Sales Forecast")
            
            # Return only future predictions
            future_forecast = forecast.tail(days)[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].copy()
            future_forecast.columns = ['date', 'yhat', 'yhat_lower', 'yhat_upper']
            
            return fig, future_forecast
            
        except Exception as e:
            st.error(f"Forecasting error: {str(e)}")
            return self._simple_forecast(df, days)
    
    def forecast_product_sales(self, df, product_name, days=30):
        """
        Forecast sales for a specific product
        """
        if not PROPHET_AVAILABLE:
            return self._simple_product_forecast(df, product_name, days)
        
        try:
            # Filter data for specific product
            product_data = df[df['product_name'] == product_name]
            
            if len(product_data) < 5:
                raise ValueError(f"Insufficient data for product '{product_name}'. Need at least 5 data points.")
            
            # Aggregate by date
            daily_product_sales = product_data.groupby('date')['total_sales'].sum().reset_index()
            daily_product_sales.columns = ['ds', 'y']
            
            # Initialize and fit Prophet model
            model = Prophet(
                daily_seasonality=False,
                weekly_seasonality=True,
                yearly_seasonality=False,  # Usually not enough data per product
                interval_width=0.95
            )
            
            model.fit(daily_product_sales)
            
            # Create future dataframe
            future = model.make_future_dataframe(periods=days)
            forecast = model.predict(future)
            
            # Create visualization
            fig = self._create_forecast_plot(
                daily_product_sales, 
                forecast, 
                f"Sales Forecast - {product_name}"
            )
            
            # Return only future predictions
            future_forecast = forecast.tail(days)[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].copy()
            future_forecast.columns = ['date', 'yhat', 'yhat_lower', 'yhat_upper']
            
            return fig, future_forecast
            
        except Exception as e:
            st.error(f"Product forecasting error: {str(e)}")
            return self._simple_product_forecast(df, product_name, days)
    
    def _create_forecast_plot(self, historical_data, forecast, title):
        """
        Create a plotly figure for forecast visualization
        """
        fig = go.Figure()
        
        # Historical data
        fig.add_trace(go.Scatter(
            x=historical_data['ds'],
            y=historical_data['y'],
            mode='lines+markers',
            name='Historical Sales',
            line=dict(color='blue')
        ))
        
        # Forecast
        forecast_start = len(historical_data)
        future_forecast = forecast.iloc[forecast_start:]
        
        fig.add_trace(go.Scatter(
            x=future_forecast['ds'],
            y=future_forecast['yhat'],
            mode='lines',
            name='Forecast',
            line=dict(color='red', dash='dash')
        ))
        
        # Confidence interval
        fig.add_trace(go.Scatter(
            x=future_forecast['ds'],
            y=future_forecast['yhat_upper'],
            mode='lines',
            line=dict(width=0),
            showlegend=False,
            hoverinfo='skip'
        ))
        
        fig.add_trace(go.Scatter(
            x=future_forecast['ds'],
            y=future_forecast['yhat_lower'],
            mode='lines',
            line=dict(width=0),
            name='Confidence Interval',
            fill='tonexty',
            fillcolor='rgba(255, 0, 0, 0.2)',
            hoverinfo='skip'
        ))
        
        fig.update_layout(
            title=title,
            xaxis_title='Date',
            yaxis_title='Sales ($)',
            hovermode='x unified',
            height=500
        )
        
        return fig
    
    def _simple_forecast(self, df, days):
        """
        Simple moving average forecast when Prophet is not available
        """
        # Aggregate data by date
        daily_sales = df.groupby('date')['total_sales'].sum().reset_index()
        
        # Calculate moving average
        window = min(7, len(daily_sales))
        recent_avg = daily_sales['total_sales'].tail(window).mean()
        
        # Create future dates
        last_date = daily_sales['date'].max()
        future_dates = [last_date + timedelta(days=i+1) for i in range(days)]
        
        # Simple forecast (recent average with slight trend)
        trend = daily_sales['total_sales'].pct_change().tail(window).mean()
        forecast_values = []
        
        for i in range(days):
            forecast_value = recent_avg * (1 + trend * i / 30)  # Apply trend gradually
            forecast_values.append(max(0, forecast_value))  # Ensure non-negative
        
        # Create forecast dataframe
        forecast_df = pd.DataFrame({
            'date': future_dates,
            'yhat': forecast_values,
            'yhat_lower': [v * 0.8 for v in forecast_values],
            'yhat_upper': [v * 1.2 for v in forecast_values]
        })
        
        # Create simple visualization
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=daily_sales['date'],
            y=daily_sales['total_sales'],
            mode='lines+markers',
            name='Historical Sales',
            line=dict(color='blue')
        ))
        
        fig.add_trace(go.Scatter(
            x=forecast_df['date'],
            y=forecast_df['yhat'],
            mode='lines',
            name='Simple Forecast',
            line=dict(color='red', dash='dash')
        ))
        
        fig.update_layout(
            title='Simple Sales Forecast (Moving Average)',
            xaxis_title='Date',
            yaxis_title='Sales ($)',
            height=500
        )
        
        return fig, forecast_df
    
    def _simple_product_forecast(self, df, product_name, days):
        """
        Simple product-specific forecast
        """
        product_data = df[df['product_name'] == product_name]
        daily_sales = product_data.groupby('date')['total_sales'].sum().reset_index()
        
        if len(daily_sales) == 0:
            # Return empty forecast
            future_dates = [datetime.now().date() + timedelta(days=i+1) for i in range(days)]
            forecast_df = pd.DataFrame({
                'date': future_dates,
                'yhat': [0] * days,
                'yhat_lower': [0] * days,
                'yhat_upper': [0] * days
            })
            
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=[], y=[], name='No Data'))
            fig.update_layout(title=f'No data available for {product_name}')
            
            return fig, forecast_df
        
        # Use same logic as simple forecast but for product
        window = min(5, len(daily_sales))
        recent_avg = daily_sales['total_sales'].tail(window).mean()
        
        last_date = daily_sales['date'].max()
        future_dates = [last_date + timedelta(days=i+1) for i in range(days)]
        
        forecast_values = [recent_avg] * days
        
        forecast_df = pd.DataFrame({
            'date': future_dates,
            'yhat': forecast_values,
            'yhat_lower': [v * 0.7 for v in forecast_values],
            'yhat_upper': [v * 1.3 for v in forecast_values]
        })
        
        # Create visualization
        fig = go.Figure()
        
        fig.add_trace(go.Scatter(
            x=daily_sales['date'],
            y=daily_sales['total_sales'],
            mode='lines+markers',
            name='Historical Sales',
            line=dict(color='blue')
        ))
        
        fig.add_trace(go.Scatter(
            x=forecast_df['date'],
            y=forecast_df['yhat'],
            mode='lines',
            name='Simple Forecast',
            line=dict(color='red', dash='dash')
        ))
        
        fig.update_layout(
            title=f'Simple Forecast - {product_name}',
            xaxis_title='Date',
            yaxis_title='Sales ($)',
            height=500
        )
        
        return fig, forecast_df
