import pandas as pd
import numpy as np
from datetime import datetime
import streamlit as st

class DataProcessor:
    def __init__(self):
        self.required_columns = ['date', 'product_name', 'quantity', 'selling_price']
        
    def process_data(self, df):
        """
        Process raw sales data: clean, validate, and calculate derived columns
        """
        try:
            # Make a copy of the dataframe
            processed_df = df.copy()
            
            # Detect and map column names (case insensitive)
            column_mapping = self._detect_columns(processed_df)
            
            # Rename columns based on mapping
            processed_df = processed_df.rename(columns=column_mapping)
            
            # Validate required columns
            missing_columns = [col for col in self.required_columns if col not in processed_df.columns]
            if missing_columns:
                raise ValueError(f"Missing required columns: {missing_columns}")
            
            # Clean and process data
            processed_df = self._clean_data(processed_df)
            processed_df = self._calculate_derived_columns(processed_df)
            processed_df = self._handle_missing_values(processed_df)
            processed_df = self._remove_duplicates(processed_df)
            
            return processed_df
            
        except Exception as e:
            raise Exception(f"Data processing error: {str(e)}")
    
    def _detect_columns(self, df):
        """
        Automatically detect and map column names to standard format
        """
        column_mapping = {}
        columns_lower = [col.lower() for col in df.columns]
        
        # Date column detection
        date_variants = ['date', 'order_date', 'purchase_date', 'transaction_date', 'sale_date']
        for variant in date_variants:
            if variant in columns_lower:
                original_col = df.columns[columns_lower.index(variant)]
                column_mapping[original_col] = 'date'
                break
        
        # Product name detection
        product_variants = ['product', 'product_name', 'item', 'item_name', 'product_id']
        for variant in product_variants:
            if variant in columns_lower:
                original_col = df.columns[columns_lower.index(variant)]
                column_mapping[original_col] = 'product_name'
                break
        
        # Quantity detection
        quantity_variants = ['quantity', 'qty', 'units', 'amount']
        for variant in quantity_variants:
            if variant in columns_lower:
                original_col = df.columns[columns_lower.index(variant)]
                column_mapping[original_col] = 'quantity'
                break
        
        # Selling price detection
        price_variants = ['price', 'selling_price', 'unit_price', 'sale_price', 'revenue']
        for variant in price_variants:
            if variant in columns_lower:
                original_col = df.columns[columns_lower.index(variant)]
                column_mapping[original_col] = 'selling_price'
                break
        
        # Cost price detection (optional)
        cost_variants = ['cost', 'cost_price', 'unit_cost', 'cogs']
        for variant in cost_variants:
            if variant in columns_lower:
                original_col = df.columns[columns_lower.index(variant)]
                column_mapping[original_col] = 'cost_price'
                break
        
        # Category detection (optional)
        category_variants = ['category', 'product_category', 'type', 'group']
        for variant in category_variants:
            if variant in columns_lower:
                original_col = df.columns[columns_lower.index(variant)]
                column_mapping[original_col] = 'category'
                break
        
        return column_mapping
    
    def _clean_data(self, df):
        """
        Clean the data: convert data types, handle dates, etc.
        """
        # Convert date column
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
        
        # Remove rows with invalid dates
        df = df.dropna(subset=['date'])
        
        # Convert numeric columns
        numeric_columns = ['quantity', 'selling_price']
        if 'cost_price' in df.columns:
            numeric_columns.append('cost_price')
        
        for col in numeric_columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Remove rows with invalid numeric data
        df = df.dropna(subset=numeric_columns)
        
        # Ensure positive values
        for col in numeric_columns:
            df = df[df[col] >= 0]
        
        # Clean product names
        df['product_name'] = df['product_name'].astype(str).str.strip()
        df = df[df['product_name'] != '']
        
        return df
    
    def _calculate_derived_columns(self, df):
        """
        Calculate derived columns like total sales and profit
        """
        # Calculate total sales
        df['total_sales'] = df['quantity'] * df['selling_price']
        
        # Calculate profit if cost price is available
        if 'cost_price' in df.columns:
            df['profit'] = df['quantity'] * (df['selling_price'] - df['cost_price'])
            df['profit_margin'] = ((df['selling_price'] - df['cost_price']) / df['selling_price'] * 100).round(2)
        else:
            # If no cost price, assume 30% profit margin for estimation
            estimated_cost = df['selling_price'] * 0.7
            df['cost_price'] = estimated_cost
            df['profit'] = df['quantity'] * (df['selling_price'] - estimated_cost)
            df['profit_margin'] = 30.0
            
            st.warning("⚠️ Cost price not provided. Using estimated 30% profit margin for calculations.")
        
        return df
    
    def _handle_missing_values(self, df):
        """
        Handle missing values in the dataset
        """
        # For category, fill with 'Uncategorized'
        if 'category' in df.columns:
            df['category'] = df['category'].fillna('Uncategorized')
        
        # For numeric columns, we've already handled this in cleaning
        return df
    
    def _remove_duplicates(self, df):
        """
        Remove duplicate records
        """
        initial_count = len(df)
        
        # Remove exact duplicates
        df = df.drop_duplicates()
        
        # Remove duplicates based on key columns (date, product, quantity, price)
        df = df.drop_duplicates(subset=['date', 'product_name', 'quantity', 'selling_price'])
        
        final_count = len(df)
        duplicates_removed = initial_count - final_count
        
        if duplicates_removed > 0:
            st.info(f"ℹ️ Removed {duplicates_removed} duplicate records")
        
        return df
    
    def get_data_summary(self, df):
        """
        Generate a summary of the processed data
        """
        summary = {
            'total_records': len(df),
            'date_range': {
                'start': df['date'].min(),
                'end': df['date'].max()
            },
            'unique_products': df['product_name'].nunique(),
            'total_sales': df['total_sales'].sum(),
            'total_profit': df['profit'].sum(),
            'categories': df['category'].nunique() if 'category' in df.columns else 0
        }
        
        return summary
