# E-Commerce Analytics & Forecasting Dashboard

## Overview

This is a comprehensive e-commerce analytics and forecasting dashboard built with Streamlit. The application enables business owners and analysts to upload sales data and gain valuable insights through interactive visualizations and predictive analytics. The system processes raw sales data, performs exploratory data analysis, and provides sales forecasting capabilities to help businesses make data-driven decisions.

The dashboard is designed to handle multiple data formats (CSV, Excel) and automatically processes and standardizes the data for analysis. It provides trend analysis, performance metrics, and forecasting capabilities through an intuitive web interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Streamlit Framework**: Web-based dashboard interface providing interactive data visualization and user interaction
- **Session State Management**: Maintains data persistence across user interactions within the same session
- **Responsive Layout**: Wide layout configuration with expandable sidebar for optimal data exploration experience

### Data Processing Pipeline
- **Modular Processing**: Separated data processing logic in dedicated `DataProcessor` class
- **Automatic Column Detection**: Intelligent mapping of various column naming conventions to standardized format
- **Data Validation**: Comprehensive validation for required columns and data quality checks
- **Derived Metrics Calculation**: Automatic computation of business metrics like profit margins and total sales

### Visualization System
- **Plotly Integration**: Interactive charts and graphs using Plotly Express and Graph Objects
- **Multi-period Analysis**: Support for daily, weekly, and monthly trend analysis
- **Color-coded Visualizations**: Consistent color palette for better user experience
- **Dynamic Chart Generation**: Real-time chart updates based on user selections and data changes

### Forecasting Engine
- **Prophet Integration**: Advanced time series forecasting using Facebook's Prophet library
- **Fallback Mechanisms**: Simple forecasting methods when Prophet is unavailable
- **Configurable Forecast Periods**: Flexible forecasting horizons (default 30 days)
- **Seasonality Detection**: Automatic detection and modeling of seasonal patterns in sales data

### Data Architecture
- **In-memory Processing**: Session-based data storage for quick analysis
- **Multiple Format Support**: CSV and Excel file processing capabilities
- **Data Standardization**: Automatic conversion to consistent data types and formats
- **Quality Assurance**: Built-in data cleaning and duplicate removal processes

## External Dependencies

### Core Framework Dependencies
- **Streamlit**: Web application framework for the dashboard interface
- **Pandas**: Data manipulation and analysis library
- **NumPy**: Numerical computing support for data processing

### Visualization Libraries
- **Plotly Express**: High-level plotting interface for quick visualizations
- **Plotly Graph Objects**: Low-level plotting interface for custom chart creation

### Forecasting Dependencies
- **Prophet**: Time series forecasting library (optional, with graceful fallback)

### Data Processing Libraries
- **Standard Python Libraries**: datetime, timedelta, io for basic data operations

### File Format Support
- **CSV Processing**: Built-in pandas CSV reading capabilities
- **Excel Processing**: pandas Excel reading support for .xlsx and .xls files

### Development and Deployment
- **Python 3.x**: Core runtime environment
- **Streamlit Cloud**: Potential deployment platform (inferred from architecture)