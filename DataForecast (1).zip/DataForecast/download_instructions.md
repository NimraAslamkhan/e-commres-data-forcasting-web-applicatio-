# Download Complete E-Commerce Analytics Dashboard

## Project Files Included:

### Main Application
- `app.py` - Main Streamlit dashboard application
- `data_processor.py` - Data cleaning and processing module
- `forecasting.py` - Sales forecasting with Prophet/fallback methods
- `visualization.py` - Chart and graph generation module

### Configuration
- `.streamlit/config.toml` - Streamlit server configuration
- `pyproject.toml` - Python dependencies
- `uv.lock` - Dependency lock file
- `replit.md` - Project documentation and architecture

## How to Run Locally:

1. **Install Python 3.11+**
2. **Install dependencies:**
   ```bash
   pip install streamlit pandas numpy plotly prophet openpyxl
   ```
3. **Run the application:**
   ```bash
   streamlit run app.py
   ```
4. **Access the dashboard at:** http://localhost:8501

## Features:
- Sales trend analysis (daily, weekly, monthly)
- Product performance analysis
- Profit analysis and margin calculations
- Sales forecasting with Prophet ML model
- Data export capabilities
- Support for CSV and Excel file uploads
- Sample data generator for testing

## Data Format:
Your data should include columns like:
- Date (any common date format)
- Product name/ID
- Quantity sold
- Selling price
- Cost price (optional)
- Category (optional)