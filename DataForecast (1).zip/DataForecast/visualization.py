import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

class Visualizer:
    def __init__(self):
        # Blue-themed color palette
        self.color_palette = ['#1f77b4', '#aec7e8', '#3498db', '#5dade2', '#85c1e9', '#aed6f1', '#d6eaf8']
        self.primary_blue = '#1f77b4'
        self.light_blue = '#aec7e8'
        self.accent_blue = '#3498db'
    
    def create_sales_trend(self, df, period='daily'):
        """
        Create sales trend visualization based on time period
        """
        # Aggregate data based on period
        if period == 'daily':
            trend_data = df.groupby('date').agg({
                'total_sales': 'sum',
                'profit': 'sum',
                'quantity': 'sum'
            }).reset_index()
            date_col = 'date'
            title = 'Daily Sales Trend'
        
        elif period == 'weekly':
            df['week'] = df['date'].dt.to_period('W').astype(str)
            trend_data = df.groupby('week').agg({
                'total_sales': 'sum',
                'profit': 'sum',
                'quantity': 'sum'
            }).reset_index()
            date_col = 'week'
            title = 'Weekly Sales Trend'
        
        elif period == 'monthly':
            df['month'] = df['date'].dt.to_period('M').astype(str)
            trend_data = df.groupby('month').agg({
                'total_sales': 'sum',
                'profit': 'sum',
                'quantity': 'sum'
            }).reset_index()
            date_col = 'month'
            title = 'Monthly Sales Trend'
        
        else:
            # Default to daily if period is not recognized
            trend_data = df.groupby('date').agg({
                'total_sales': 'sum',
                'profit': 'sum',
                'quantity': 'sum'
            }).reset_index()
            date_col = 'date'
            title = 'Daily Sales Trend'
        
        # Create the plot
        fig = go.Figure()
        
        # Sales line
        fig.add_trace(go.Scatter(
            x=trend_data[date_col],
            y=trend_data['total_sales'],
            mode='lines+markers',
            name='Sales',
            line=dict(color=self.primary_blue, width=3),
            marker=dict(size=8, color=self.primary_blue),
            fill='tonexty' if len(fig.data) == 0 else None,
            fillcolor='rgba(31, 119, 180, 0.1)'
        ))
        
        # Profit line on secondary y-axis
        fig.add_trace(go.Scatter(
            x=trend_data[date_col],
            y=trend_data['profit'],
            mode='lines+markers',
            name='Profit',
            line=dict(color=self.accent_blue, width=3),
            marker=dict(size=8, color=self.accent_blue),
            yaxis='y2'
        ))
        
        # Update layout with secondary y-axis
        fig.update_layout(
            title=dict(text=title, font=dict(color=self.primary_blue, size=18)),
            xaxis_title='Time Period',
            yaxis=dict(
                title=dict(text='Sales ($)', font=dict(color=self.primary_blue)),
                side='left',
                tickfont=dict(color=self.primary_blue)
            ),
            yaxis2=dict(
                title=dict(text='Profit ($)', font=dict(color=self.accent_blue)),
                side='right',
                overlaying='y',
                tickfont=dict(color=self.accent_blue)
            ),
            hovermode='x unified',
            height=400,
            showlegend=True,
            plot_bgcolor='rgba(248, 250, 252, 0.8)',
            paper_bgcolor='white',
            font=dict(family="Arial", size=12, color='#1e293b')
        )
        
        return fig
    
    def create_category_analysis(self, df):
        """
        Create category-wise sales analysis
        """
        if 'category' not in df.columns:
            return go.Figure().add_annotation(text="No category data available")
        
        category_data = df.groupby('category').agg({
            'total_sales': 'sum',
            'profit': 'sum',
            'quantity': 'sum'
        }).reset_index()
        
        # Create pie chart for sales distribution
        fig = px.pie(
            category_data,
            values='total_sales',
            names='category',
            title='Sales Distribution by Category',
            color_discrete_sequence=self.color_palette
        )
        
        fig.update_traces(textposition='inside', textinfo='percent+label')
        fig.update_layout(
            height=400,
            plot_bgcolor='rgba(248, 250, 252, 0.8)',
            paper_bgcolor='white',
            title_font_color=self.primary_blue, title_font_size=16,
            font=dict(family="Arial", size=12, color='#1e293b')
        )
        
        return fig
    
    def create_top_products_chart(self, products_data, metric='total_sales', ascending=False):
        """
        Create horizontal bar chart for top/worst products
        """
        # Sort data
        sorted_data = products_data.sort_values(metric, ascending=ascending)
        
        # Create horizontal bar chart
        fig = px.bar(
            sorted_data,
            x=metric,
            y=sorted_data.index,
            orientation='h',
            title=f"Products by {metric.replace('_', ' ').title()}",
            color=metric,
            color_continuous_scale=['#e6f3ff', '#3498db', '#1f77b4'] if not ascending else ['#fef2f2', '#f87171', '#dc2626']
        )
        
        fig.update_layout(
            height=400,
            yaxis={'categoryorder': 'total ascending' if ascending else 'total descending'},
            plot_bgcolor='rgba(248, 250, 252, 0.8)',
            paper_bgcolor='white',
            title_font_color=self.primary_blue, title_font_size=16,
            font=dict(family="Arial", size=12, color='#1e293b')
        )
        
        return fig
    
    def create_profit_analysis(self, profit_data, is_low_profit=False):
        """
        Create profit analysis visualization
        """
        # Create scatter plot: Profit vs Sales
        fig = px.scatter(
            profit_data,
            x='total_sales',
            y='profit',
            size='quantity',
            hover_name=profit_data.index,
            title='Profit vs Sales Analysis' + (' (Low Profit Items)' if is_low_profit else ''),
            labels={
                'total_sales': 'Total Sales ($)',
                'profit': 'Total Profit ($)',
                'quantity': 'Quantity Sold'
            },
            color='profit_margin' if 'profit_margin' in profit_data.columns else 'profit',
            color_continuous_scale=['#fef2f2', '#f87171', '#dc2626'] if is_low_profit else ['#e6f3ff', '#3498db', '#1f77b4']
        )
        
        fig.update_layout(
            height=400,
            plot_bgcolor='rgba(248, 250, 252, 0.8)',
            paper_bgcolor='white',
            title_font_color=self.primary_blue, title_font_size=16,
            font=dict(family="Arial", size=12, color='#1e293b')
        )
        
        return fig
    
    def create_time_series_decomposition(self, df):
        """
        Create a time series decomposition view
        """
        # Aggregate daily sales
        daily_sales = df.groupby('date')['total_sales'].sum().reset_index()
        
        # Calculate moving averages
        daily_sales['7_day_ma'] = daily_sales['total_sales'].rolling(window=7).mean()
        daily_sales['30_day_ma'] = daily_sales['total_sales'].rolling(window=30).mean()
        
        fig = go.Figure()
        
        # Actual sales
        fig.add_trace(go.Scatter(
            x=daily_sales['date'],
            y=daily_sales['total_sales'],
            mode='lines',
            name='Daily Sales',
            line=dict(color='lightblue', width=1),
            opacity=0.7
        ))
        
        # 7-day moving average
        fig.add_trace(go.Scatter(
            x=daily_sales['date'],
            y=daily_sales['7_day_ma'],
            mode='lines',
            name='7-Day Moving Average',
            line=dict(color='blue', width=2)
        ))
        
        # 30-day moving average
        fig.add_trace(go.Scatter(
            x=daily_sales['date'],
            y=daily_sales['30_day_ma'],
            mode='lines',
            name='30-Day Moving Average',
            line=dict(color='red', width=2)
        ))
        
        fig.update_layout(
            title='Sales Trend with Moving Averages',
            xaxis_title='Date',
            yaxis_title='Sales ($)',
            height=400,
            hovermode='x unified'
        )
        
        return fig
    
    def create_seasonal_analysis(self, df):
        """
        Create seasonal pattern analysis
        """
        # Add time-based features
        df_copy = df.copy()
        df_copy['day_of_week'] = df_copy['date'].dt.day_name()
        df_copy['month'] = df_copy['date'].dt.month_name()
        df_copy['hour'] = df_copy['date'].dt.hour if 'time' in df_copy.columns else 12
        
        # Day of week analysis
        dow_sales = df_copy.groupby('day_of_week')['total_sales'].sum().reindex([
            'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
        ])
        
        fig = px.bar(
            x=dow_sales.index,
            y=dow_sales.values,
            title='Sales by Day of Week',
            labels={'x': 'Day of Week', 'y': 'Total Sales ($)'},
            color=dow_sales.values,
            color_continuous_scale='Blues'
        )
        
        fig.update_layout(height=400)
        
        return fig
    
    def create_correlation_heatmap(self, df):
        """
        Create correlation heatmap for numerical variables
        """
        # Select numerical columns
        numerical_cols = ['quantity', 'selling_price', 'total_sales', 'profit']
        if 'cost_price' in df.columns:
            numerical_cols.append('cost_price')
        
        correlation_matrix = df[numerical_cols].corr()
        
        fig = px.imshow(
            correlation_matrix,
            title='Correlation Matrix of Key Metrics',
            color_continuous_scale='RdBu',
            aspect='auto'
        )
        
        fig.update_layout(height=400)
        
        return fig
